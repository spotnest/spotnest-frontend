"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";

import DashboardShell from "@/src/modules/dashboard/components/DashboardShell";
import OwnerApprovalRequestCard from "@/src/modules/auth/components/OwnerApprovalRequestCard";

import {
    useOwnerApprovalRequests,
    ownerApprovalRequestsQueryKey,
} from "@/src/modules/auth/hooks/useOwnerApprovalRequests";

import {
    approveOwner,
    rejectOwner,
} from "@/src/modules/auth/services/authServices";

import { useAdminVisits } from "@/src/modules/visits/hooks/useAdminVisits";
import AdminVisitCard from "@/src/modules/visits/components/AdminVisitCard";

import { dashboardPathForRole } from "@/src/constants/routes";
import { useAppSelector } from "@/src/store/hook";

const messageFromError = (
    error: unknown,
    fallback: string
): string => {
    if (
        axios.isAxiosError(error) &&
        typeof error.response?.data?.message === "string"
    ) {
        return error.response.data.message;
    }

    return fallback;
};

export default function OwnerApprovalRequestsPage() {
    const router = useRouter();
    const queryClient = useQueryClient();

    const { user, isInitialized } = useAppSelector(
        (state) => state.auth
    );

    const isAdmin = user?.role === "admin";
    const canLoadAdminData = isInitialized && isAdmin;

    const [activeRequestId, setActiveRequestId] =
        useState<string | null>(null);

    const [feedback, setFeedback] = useState("");
    const [error, setError] = useState("");

    const requestsQuery = useOwnerApprovalRequests(
        canLoadAdminData
    );

    const visitsQuery = useAdminVisits(
        {
            page: 1,
            limit: 20,
        },
        canLoadAdminData
    );

    useEffect(() => {
        if (isInitialized && user && !isAdmin) {
            router.replace(
                dashboardPathForRole(user.role)
            );
        }
    }, [isInitialized, isAdmin, router, user]);

    const refreshApprovalData = async () => {
        await Promise.all([
            queryClient.invalidateQueries({
                queryKey: ownerApprovalRequestsQueryKey,
            }),
            queryClient.invalidateQueries({
                queryKey: ["admin-dashboard"],
            }),
            queryClient.invalidateQueries({
                queryKey: ["admin-users"],
            }),
        ]);
    };

    const approveMutation = useMutation({
        mutationFn: approveOwner,

        onSuccess: async (data) => {
            setFeedback(data.message);
            setError("");
            await refreshApprovalData();
        },

        onError: (mutationError: unknown) => {
            setError(
                messageFromError(
                    mutationError,
                    "Unable to approve this request."
                )
            );
        },

        onSettled: () => {
            setActiveRequestId(null);
        },
    });

    const rejectMutation = useMutation({
        mutationFn: rejectOwner,

        onSuccess: async (data) => {
            setFeedback(data.message);
            setError("");
            await refreshApprovalData();
        },

        onError: (mutationError: unknown) => {
            setError(
                messageFromError(
                    mutationError,
                    "Unable to reject this request."
                )
            );
        },

        onSettled: () => {
            setActiveRequestId(null);
        },
    });

    const approveRequest = (userId: string) => {
        if (
            activeRequestId ||
            approveMutation.isPending ||
            rejectMutation.isPending
        ) {
            return;
        }

        setFeedback("");
        setError("");
        setActiveRequestId(userId);

        approveMutation.mutate(userId);
    };

    const rejectRequest = (
        userId: string,
        reason: string
    ) => {
        if (
            activeRequestId ||
            approveMutation.isPending ||
            rejectMutation.isPending
        ) {
            return;
        }

        const trimmedReason = reason.trim();

        if (!trimmedReason) {
            setError("A rejection reason is required.");
            return;
        }

        setFeedback("");
        setError("");
        setActiveRequestId(userId);

        rejectMutation.mutate({
            userId,
            reason: trimmedReason,
        });
    };

    if (!isInitialized || !isAdmin) {
        return null;
    }

    return (
        <DashboardShell role="admin">
            <main className="mx-auto max-w-[1500px] px-4 py-7 sm:px-6 sm:py-9 lg:px-10 lg:py-10">
                <p className="text-sm font-semibold text-[#00696b]">
                    Admin workspace
                </p>

                <h1 className="mt-2 text-3xl font-bold tracking-[-0.04em] text-[#191c1d]">
                    Requests
                </h1>

                <p className="mt-2 text-sm leading-6 text-[#44474d]">
                    Review Property Owner account approval
                    requests.
                </p>

                {feedback && (
                    <p
                        role="status"
                        className="mt-6 rounded-xl border border-[#9bd9d6] bg-[#d9f4f3] px-4 py-3 text-sm font-semibold text-[#00696b]"
                    >
                        {feedback}
                    </p>
                )}

                {error && (
                    <p
                        role="alert"
                        className="mt-6 rounded-xl border border-[#f0b5ae] bg-[#fff0ee] px-4 py-3 text-sm font-semibold text-[#b42318]"
                    >
                        {error}
                    </p>
                )}

                <section
                    className="mt-8"
                    aria-label="Pending Property Owner approval requests"
                >
                    {requestsQuery.isLoading ? (
                        <div className="rounded-2xl border border-[#e1e3e4] bg-white px-5 py-10 text-center text-sm text-[#75777e]">
                            Loading approval requests...
                        </div>
                    ) : requestsQuery.isError ? (
                        <div className="rounded-2xl border border-[#f0b5ae] bg-[#fff0ee] px-5 py-8 text-sm text-[#b42318]">
                            Unable to load approval requests.
                            Please refresh and try again.
                            <button
                                type="button"
                                onClick={() => requestsQuery.refetch()}
                                className="ml-2 font-semibold underline"
                            >
                                Retry
                            </button>
                        </div>
                    ) : requestsQuery.data?.length ? (
                        <div className="grid gap-4 lg:grid-cols-2">
                            {requestsQuery.data.map((request) => (
                                <OwnerApprovalRequestCard
                                    key={request.id}
                                    request={request}
                                    isProcessing={
                                        activeRequestId === request.id &&
                                        (
                                            approveMutation.isPending ||
                                            rejectMutation.isPending
                                        )
                                    }
                                    onApprove={approveRequest}
                                    onReject={rejectRequest}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="rounded-2xl border border-dashed border-[#c5c6cd] bg-white px-5 py-12 text-center">
                            <p className="text-sm font-bold text-[#191c1d]">
                                No approval requests
                            </p>
                            <p className="mt-1 text-sm text-[#75777e]">
                                New Property Owner requests
                                will appear here.
                            </p>
                        </div>
                    )}
                </section>

                <section
                    className="mt-10 rounded-2xl border border-[#e1e3e4] bg-white p-5 shadow-sm sm:p-6"
                    aria-label="Visit requests"
                >
                    <div className="flex flex-col gap-1">
                        <h2 className="text-xl font-bold tracking-[-0.02em] text-[#191c1d]">
                            Visit Requests
                        </h2>

                        <p className="text-sm text-[#75777e]">
                            Monitor property visit requests and
                            their current status.
                        </p>
                    </div>

                    <div className="mt-6">
                        {visitsQuery.isLoading ? (
                            <div className="rounded-xl border border-[#e1e3e4] bg-[#fafafa] px-5 py-10 text-center text-sm text-[#75777e]">
                                Loading visit requests...
                            </div>
                        ) : visitsQuery.isError ? (
                            <div className="rounded-xl border border-[#f0b5ae] bg-[#fff0ee] px-5 py-8 text-sm text-[#b42318]">
                                Unable to load visit requests.
                                Please refresh and try again.
                                <button
                                    type="button"
                                    onClick={() => visitsQuery.refetch()}
                                    className="ml-2 font-semibold underline"
                                >
                                    Retry
                                </button>
                            </div>
                        ) : visitsQuery.data?.visits.length ? (
                            <>
                                <div className="grid gap-4 lg:grid-cols-2">
                                    {visitsQuery.data.visits.map((visit) => (
                                        <AdminVisitCard
                                            key={visit._id}
                                            visit={visit}
                                            onRefresh={() => visitsQuery.refetch()}
                                        />
                                    ))}
                                </div>

                                <p className="mt-4 text-sm text-[#75777e]">
                                    Showing {visitsQuery.data.visits.length}
                                    {" "}of {visitsQuery.data.pagination.total}
                                    {" "}visit requests.
                                </p>
                            </>
                        ) : (
                            <div className="rounded-xl border border-dashed border-[#c5c6cd] bg-[#fafafa] px-5 py-12 text-center">
                                <p className="text-sm font-bold text-[#191c1d]">
                                    No visit requests
                                </p>
                                <p className="mt-1 text-sm text-[#75777e]">
                                    New property visit requests
                                    will appear here.
                                </p>
                            </div>
                        )}
                    </div>
                </section>
            </main>
        </DashboardShell>
    );
}
